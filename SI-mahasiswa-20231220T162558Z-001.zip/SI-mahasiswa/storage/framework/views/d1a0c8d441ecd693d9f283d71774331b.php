<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; SI-Mahasiswa 2023</span>
        </div>
    </div>
</footer><?php /**PATH D:\laragon\www\SI-mahasiswa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>