@extends('layouts.app')

@section('title', 'SI-Mahasiswa || Dashboard')

@section('contents')
    <div class="row">
        Dashboard
    </div>
@endsection